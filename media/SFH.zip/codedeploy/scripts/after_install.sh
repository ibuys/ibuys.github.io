#!/bin/bash

aws configure set default.s3.signature_version s3v4
rm -rf /root/.docker/
mkdir -p /root/.docker/

mv /tmp/brain/qa.txt /etc/qa.txt
# mv /tmp/config.json /root/.docker/config.json

rm -rf /etc/nginx/conf.d
mv /tmp/brain/conf.d /etc/nginx/conf.d
mv /tmp/brain/nginx.conf /etc/nginx/nginx.conf
mv /tmp/brain/public /var/www/brain/current/public

# Carry on...

cd /tmp/brain/; docker build -t brain .
