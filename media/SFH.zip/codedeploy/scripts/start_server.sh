#!/bin/bash

/etc/init.d/nginx start

# docker run -d --name ubuntu --restart=always --env-file=/etc/qa.txt -p 8080:8080 ubuntu



docker run -d --env-file=/etc/qa.txt -p 8080:8080 brain
