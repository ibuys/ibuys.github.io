#!/bin/bash

rm -rf  /tmp/brain/
mkdir -p /var/www/brain/current/

yum install -y docker
/etc/init.d/docker start
chkconfig docker on

# useradd brain
# sudo -u brain bash -lc "cd ~/brain; bundle list"
# 
# mkdir /var/log/www
# mkdir /var/www/brain
# 
# touch /var/log/www/brain.stderr.log
# touch /var/log/www/brain.stdout.log
# touch /var/log/www/brain.application.log
# 
# chown -R brain /var/www/brain
# chown -R brain /var/log/www
# 
# rm -rf /var/www/brain/current/
