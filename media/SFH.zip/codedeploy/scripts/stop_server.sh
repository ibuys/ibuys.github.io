#!/bin/bash

/etc/init.d/nginx stop

CONTAINER=ubuntu

RUNNING=$(docker inspect --format="{{ .State.Running }}" $CONTAINER 2> /dev/null)

if [ $? -eq 1 ]; then
  echo "$CONTAINER does not exist."
  exit 0
fi

if [ "$RUNNING" == "false" ]; then
  echo "$CONTAINER is not running."
  exit 0
else
  docker stop $CONTAINER
  docker rm -v $CONTAINER
fi

# Delete all containers
docker rm $(docker ps -a -q)
# Delete all images
docker rmi $(docker images -q)
