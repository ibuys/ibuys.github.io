#!/bin/sh
source ~/Unix/env/bin/activate

# Just so I don't accidentally try to deploy from the wrong directory.
# This won't be needed in Hudson.
# cd /Users/Jonathan/Documents/Home/Stitch\ Fix/stitch-fix-cf/codedeploy

# One Time Role ARN Setup
# aws iam create-role --role-name CodeDeployServiceRole --assume-role-policy-document file://CodeDeployDemo-Trust.json
# aws iam attach-role-policy --role-name CodeDeployServiceRole --policy-arn arn:aws:iam::aws:policy/service-role/AWSCodeDeployRole

# APPNAME=Brain
# STACKNAME=`aws cloudformation describe-stack-resources --stack-name fh-qa-core-stack | grep $APPNAME | awk -F/ '{ print $2 }'`
# AUTOSCALE=`aws cloudformation describe-stack-resources --stack-name fh-qa-core-stack | grep PhysicalResourceId | grep DockerServerAutoScale | grep -v arn\:aws | awk '{ print $2 }' | sed s/\"//g | sed s/,//g`
# ROLEARN=`aws iam get-role --role-name CodeDeployServiceRole --query "Role.Arn" --output text`
# echo $AUTOSCALE
# 
# # Run once, then comment out for account.
# aws deploy create-application --application-name resque-brain
# aws deploy delete-deployment-group --application-name resque-brain --deployment-group-name resque-brain_DepGroup 
# 	
# aws deploy create-deployment-group \
# --application-name resque-brain \
# --deployment-group-name resque-brain_DepGroup \
# --deployment-config-name CodeDeployDefault.OneAtATime \
# --auto-scaling-groups $AUTOSCALE \
# --service-role-arn $ROLEARN

aws deploy push \
--application-name resque-brain \
--s3-location s3://qarailss3bucket/resque-brain.zip \
--ignore-hidden-files

aws deploy create-deployment \
--application-name resque-brain \
--deployment-config-name CodeDeployDefault.OneAtATime \
--deployment-group-name resque-brain-dep-group \
--s3-location bucket=qarailss3bucket,bundleType=zip,key=resque-brain.zip
