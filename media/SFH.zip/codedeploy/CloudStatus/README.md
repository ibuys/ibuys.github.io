# Cloud Status
A simple menubar status item tracking your iCloud Drive uploading / downloading status globally and per app.

Icons generated from Font Awesome by Dave Gandy - http://fontawesome.io. If you are a gifted icon designer: A better app icon and an icon for bidirectional transfers is highly appreciated ;).

## Legal
See "LICENSE" for licensing. iCloud is a registered trademark of Apple Inc.
