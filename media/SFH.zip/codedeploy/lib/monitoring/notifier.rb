module Monitoring
  class Notifier

    # This will be given an array of CheckResult instances
    def notify!(check_results)
      raise
    end
  end
end
