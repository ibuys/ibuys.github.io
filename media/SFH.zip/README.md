# Stitch Fix Homework

## Explanation and Reasoning

I’m assuming that the purpose of this assignment is to assess my skills and problem solving ability. The assignment as presented is to automate changing the credentials for the Postgres server and the Redis server. The Redis server is a web service without an API, and the Postgres server is running as part of the Heroku services. From what I can tell, updating an environmental variable in Heroku will trigger the applications to restart, so anything running on Heroku doesn’t seem like much of an issue. Getting that new credential to AWS seems like the bigger problem, as is getting the new credential out to the various web services. 

A problem with keeping one variable in sync between disparate platforms is really an issue with the overall management system. Since I’m unaware of the intricacies of the platform, I’ve decided that the best way to showcase my skills and abilities is to build an AWS automation system based on CloudFormation, CodeDeploy, and Docker. 

First, I downloaded a Rails application from Github, [resque-brain], and created a Dockerfile to run the application in a Docker container. I then deployed the application to Heroku, and familiarized myself with the Heroku toolbelt. 

Next, I created a CloudFormation template that builds a secure environment to run the application. There is no remote access to the host, and the only way to get to the application is through an Elastic Load Balancer. The application runs in an auto scaling group that triggers based on the load average of the instance. 

I then created a CodeDeploy script to deploy the application to the auto scaling group. The script is inefficient though, and not suitable for production use. The script uploads the application source code and builds and runs the Docker image. This takes far too long (normally around ten minutes). In a production system I would have the image in a private registry and would pull it as needed. However, for the purposes of this demonstration I determined that the partial solution was adequate. 

Finally, I wrote a small shell script and associated CodeDeploy scripts to update the Redis or Postgres credentials and update the appropriate environment. The Postgres credentials are updated on Heroku first, the script parses out the connection string, and then updates the Docker image running on AWS. To update the Redis credentials, I assume that the credentials would be updated in the Redis Cloud web app first, and then copied and pasted as an argument to the script. 

## Setup

This setup assumes that the Heroku toolbelt and AWS credentials and command line tools are installed. No other setup on AWS is required. 

To build the AWS environment, cd into the cloudformation directory and run this command:

	aws cloudformation create-stack --stack-name fh-qa-core-stack --template-body file:////`pwd`/qa.json --capabilities CAPABILITY_IAM

If the source files are modified, the qa.json file can be rebuilt:

	./build.py | jq '.' | jsmin > qa.json

Both `jq` and `jsmin` can be installed through [Homebrew].

Setup can be monitored through the CloudFormation AWS console. Once complete, cd into the codedeploy directory and run the `./setup.sh` script. This portion can also be monitored through the AWS console, and is expected to take 10-15 minutes. 

Once CodeDeploy has completed successfully, the Elastic Load Balancer will show a single instance as being “in service”. Copy  the ELB DNS name and append `:8080` to open the application. 


## Subsequent Updates
Finally, after deployment is complete on both Heroku and AWS, the `update_creds.sh` script in the credentials directory can be used to update either the Redis or Postgres environmental variables. 

To update Postgres credentials:

	update_creds.sh -p 

To update Redis credentials: 

	update_creds.sh -r new_redis_password

## Closing Thoughts

This assignment was challenging, and I admit that I did not tackle the requested work head-on. I think that I did not have a good enough understanding of the existing environment or the specific pain that I was trying to solve. I didn’t attempt to automate updating the web sites without an API, as I felt that something as infrequently (I would assume quarterly) changed as database credentials could probably be done manually. The other option I explored was automating the change using a web scraping framework like Python  MechanicalSoup. However, after consideration and some exploration this solution seemed far too fragile. Of course, I’m always open to giving it a shot. 

I hope that what I’ve submitted provides a good overview of my skills and problem solving methods. It’s a rough solution, and not nearly as bullet proof as I’d like it to be, but I think it would be a good foundation for future work to automate the distribution of any updates through the various environments. The tool tying into the AWS and Heroku APIs could be anything from a shell script to a web application. 

I’m open to feedback, and would love to discuss any aspect of the homework. 
