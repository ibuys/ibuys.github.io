#!/bin/bash

/etc/init.d/nginx stop

docker stop $(docker ps -a -q)