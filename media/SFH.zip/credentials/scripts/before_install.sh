#!/bin/bash

rm -rf  /tmp/brainvar/
