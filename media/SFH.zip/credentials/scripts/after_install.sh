#!/bin/bash


mv /tmp/brainvar/qa.txt /etc/qa.txt
