#!/bin/sh
source ~/Unix/env/bin/activate

awsDeploy ()
{
	aws deploy push \
	--application-name resque-brain \
	--s3-location s3://qarailss3bucket/resque-brain.zip \
	--ignore-hidden-files

	aws deploy create-deployment \
	--application-name resque-brain \
	--deployment-config-name CodeDeployDefault.OneAtATime \
	--deployment-group-name resque-brain-dep-group \
	--s3-location bucket=qarailss3bucket,bundleType=zip,key=resque-brain.zip
	
	echo "Update Complete"
}

updatePostgres ()
{ 
	heroku pg:credentials DATABASE_URL --reset --app sheltered-forest-83833
	NEWCREDS=`heroku pg:credentials DATABASE_URL --app sheltered-forest-83833 | grep postgres`
	NEWCREDS_FINAL=`echo $NEWCREDS | sed "s|postgres://||g"`
	REDSISREDS=`cat qa.txt | grep REDIS_CREDS | awk -F= '{ print $2 }'`

	cat qa_template.txt | sed "s|QQREDISCREDS|$REDSISREDS|g"| sed "s|QQDBCREDS|$NEWCREDS_FINAL|g" > qa.txt
	echo $NEWCREDS_FINAL | pbcopy
	echo "New Postgres credentials have been copied to the clipboard."
	awsDeploy
}

updateRedis ()
{
	NEWCREDS=$1
	echo $NEWCREDS
	POSTCREDS=`cat qa.txt | grep DATA | awk -F= '{ print $2 }' | sed 's|postgres://||g'`
	# Well, this is silly. Honestly I'd probably refactor this. 
	cat qa_template.txt | sed "s|QQREDISCREDS|$NEWCREDS|g" | sed "s|QQDBCREDS|$POSTCREDS|g" > qa.txt
	heroku config:set REDIS_CREDS=$NEWCREDS
	awsDeploy
}

show_help() {
    echo $0: usage: update_creds.sh [-p] [-r] redis-credentials
}

if [[ $# < 1 ]]; then
    echo $0: usage: update_creds.sh [-p] [-r] redis-credentials
    exit 1
fi

while [[ $1 == -* ]]; do
    case "$1" in
      -p|--postgres) updatePostgres; exit 0;;
      -r|--redis) updateRedis $2; exit 0;;
      --) shift; break;;
      -*) echo "invalid option: $1" 1>&2; show_help; exit 1;;
    esac
done


