# Core VPC CloudFormation

Run the build script and run it through the `jq` JSON parser to validate correct syntax. 

	./build.py | jq '.'

After `jq` returns formatted, color coded JSON, run the build script again and redirect output to a file named **qa.json**. 

	./build.py > qa.json

Validate the JSON file:

	aws cloudformation validate-template --template-body file:////`pwd`/qa.json

Finally, assuming the file validates, run the `aws cloudformation` command to upload the JSON. 

	aws cloudformation create-stack --stack-name fh-qa-core-stack --template-body file:////`pwd`/qa.json --capabilities CAPABILITY_IAM

The command should return a StackId:

	{
		"StackId": "arn:aws:cloudformation:us-west-2:067712708126:stack/fh-qa-core-stack/8fb39d60-fd58-11e4-8fd3-500160d4da7c"
	}

Open the AWS Console, navigate to CloudFormation, and view the events until the status of the stack is “CREATE_COMPLETE”. 


