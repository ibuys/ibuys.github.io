#!/usr/bin/env python


params_file=open("parameters.json", "r") 
secgroups_file=open("security_groups.json", "r") 
network_file=open("network.json", "r")
s3_file=open("s3.json", "r")
mappings_file=open("mappings.json", "r") 
acl_file=open("acl.json", "r") 
iam_file=open("iam.json", "r")
cd_file=open("codedeploy.json", "r")
nested_file=open("nested.json", "r")
outputs_file=open("outputs.json", "r")
base_file=open("base.json", "r")

parameters=params_file.read()
secgroups=secgroups_file.read()
network=network_file.read()
s3=s3_file.read()
mappings=mappings_file.read()
acl=acl_file.read()
iam=iam_file.read()
codedeploy=cd_file.read()
nested=nested_file.read()
outputs=outputs_file.read()
base=base_file.read()

base = base.replace("QQ_PARAMETERS", parameters)
base = base.replace("QQ_MAPPINGS", mappings)
base = base.replace("QQ_NETWORK", network)
base = base.replace("QQ_S3", s3)
base = base.replace("QQ_ACL", acl)
base = base.replace("QQ_IAM", iam)
base = base.replace("QQ_CODEDEPLOY", codedeploy)
base = base.replace("QQ_NESTED", nested)
base = base.replace("QQ_OUTPUTS", outputs)
base = base.replace("QQ_SECURITY_GROUPS", secgroups)

print base

