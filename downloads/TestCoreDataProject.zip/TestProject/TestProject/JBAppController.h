//
//  JBAppController.h
//  Moose
//
//  Created by Jonathan Buys on 1/7/20.
//  Copyright © 2020 Jonathan Buys. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface JBAppController : NSObject
{
    IBOutlet NSArrayController *bookmarksController;
}

@property (nonatomic, readonly) NSManagedObjectContext* managedObjectContext;

@end

NS_ASSUME_NONNULL_END
