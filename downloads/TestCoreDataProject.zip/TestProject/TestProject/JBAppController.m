//
//  JBAppController.m
//  Moose
//
//  Created by Jonathan Buys on 1/7/20.
//  Copyright © 2020 Jonathan Buys. All rights reserved.
//

#import "JBAppController.h"
#import "AppDelegate.h"

@implementation JBAppController

//-(void)applicationDidFinishLaunching
//{
//    NSLog(@"applicationDidFinishLaunching");
//    [bookmarksController setManagedObjectContext:[self managedObjectContext]];
//}

- (NSManagedObjectContext*)managedObjectContext
{
    return [[(AppDelegate *)[[NSApplication sharedApplication] delegate] persistentContainer] viewContext];
}


@end
